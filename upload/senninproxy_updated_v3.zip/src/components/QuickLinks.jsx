import clsx from 'clsx';
import { useNavigate } from 'react-router-dom';
import { useOptions } from '/src/utils/optionsContext';
import { Plus, Bolt, Globe, Pencil, Trash2, CircleX } from 'lucide-react';
import { useState, useEffect, useRef } from 'react';
import LinkDialog from './NewQuickLink';
import EditLinkDialog from './EditQuickLink';
import '/src/styles/chrome.css';

// removed from the home page; also filtered out of links saved before this change
const REMOVED_LINKS = ['https://cineby.gd'];

const QuickLinks = ({ cls, nav = true, navigating }) => {
  const { options, updateOption } = useOptions();
  const navigate = useNavigate();
  const [fallback, setFallback] = useState({});
  const [menuOpen, setMenuOpen] = useState(null);
  const [dialog, setDialog] = useState({ add: false, edit: false, index: null });
  const [shiftHeld, setShiftHeld] = useState(false);
  const menuRef = useRef(null);

  const defaultLinks = [
    { link: 'https://google.com', icon: 'https://google.com/favicon.ico', name: 'Google' },
    { link: 'https://discord.com', icon: '/assets/img/dsci.ico', name: 'Discord' },
    { link: 'https://github.com', icon: '/assets/img/icogh.ico', name: 'GitHub' },
  ];

  const [quickLinks, setQuickLinks] = useState(() => {
    try {
      const saved = JSON.parse(localStorage.getItem('options'))?.quickLinks || defaultLinks;
      return saved.filter((l) => !REMOVED_LINKS.includes(l.link));
    } catch {
      return defaultLinks;
    }
  });

  const go = (url) => {
    if (nav) {
      navigate("/search", {
        state: {
          url: url,
        }
      });
    } else {
      const processedUrl = navigating.process(url);
      if (processedUrl) {
        navigating.go(navigating.id, processedUrl);
      }
    }
  };

  useEffect(() => {
    const close = (e) => !menuRef.current?.contains(e.target) && setMenuOpen(null);
    const down = (e) => e.key === 'Shift' && setShiftHeld(true);
    const up = (e) => e.key === 'Shift' && setShiftHeld(false);
    document.addEventListener('mousedown', close);
    document.addEventListener('keydown', down);
    document.addEventListener('keyup', up);
    return () => {
      document.removeEventListener('mousedown', close);
      document.removeEventListener('keydown', down);
      document.removeEventListener('keyup', up);
    };
  }, []);

  useEffect(() => updateOption({ quickLinks }), [quickLinks]);

  useEffect(() => {
    setFallback({});
  }, [quickLinks]);

  const linkItem = clsx(
    'flex flex-col items-center justify-center relative group w-20 h-[5.5rem] rounded-xl border border-transparent cursor-pointer duration-200 ease-out text-[#202124]',
    'hover:bg-[#f1f3f4] hover:border-[#e8eaed]',
  );
  const linkLogo = 'w-[2.5rem] h-[2.5rem] flex items-center justify-center rounded-full bg-[#f1f3f4] transition-transform duration-200 ease-out group-hover:scale-105';

  return (
    <div className={clsx('flex flex-wrap justify-center gap-4', cls || 'w-full max-w-[40rem] mx-auto mt-[16rem]')}>
      {quickLinks.map((link, i) => (
        <div key={i} className={linkItem} onClick={() => go(link.link)}>
          <div
            ref={menuOpen === i ? menuRef : null}
            onClick={(e) => {
              e.stopPropagation();
              shiftHeld ? setQuickLinks(quickLinks.filter((_, j) => j !== i)) : setMenuOpen(menuOpen === i ? null : i);
            }}
            className={clsx(
              'absolute -top-2 -right-2 duration-200 ease',
              menuOpen === i ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
            )}
          >
            {shiftHeld ? <CircleX size="16" className="opacity-70 text-red-500" /> : <Bolt size="16" className="opacity-50" />}
            {menuOpen === i && (
              <div
                className="chrome-menu chrome-menu-in absolute top-5 right-0 rounded-lg py-1 w-[120px] z-50 text-[#202124]"
                onClick={(e) => e.stopPropagation()}
              >
                <button
                  onClick={() => setDialog({ add: false, edit: true, index: i }) || setMenuOpen(null)}
                  className="chrome-menu-item w-full px-3 py-2 text-[0.78rem] flex items-center gap-2 text-left"
                >
                  <Pencil size="14" className="opacity-70" /> 編集
                </button>
                <button
                  onClick={() => setQuickLinks(quickLinks.filter((_, j) => j !== i)) || setMenuOpen(null)}
                  className="chrome-menu-item w-full px-3 py-2 text-[0.78rem] flex items-center gap-2 text-left text-[#d93025]"
                >
                  <Trash2 size="14" /> 削除
                </button>
              </div>
            )}
          </div>

          <div className={linkLogo}>
            {fallback[i] ? (
              <Globe className="w-7 h-7" />
            ) : (
              <img
                key={link.icon}
                src={link.icon}
                alt={link.name}
                className="w-7 h-7 object-contain"
                loading="lazy"
                onError={() => setFallback((p) => ({ ...p, [i]: true }))}
              />
            )}
          </div>
          <div className="mt-3 text-sm font-medium text-center w-full px-1 overflow-hidden whitespace-nowrap text-ellipsis text-[#202124]">
            {link.name}
          </div>
        </div>
      ))}

      <div className={linkItem} onClick={() => setDialog({ add: true, edit: false, index: null })}>
        <div className={linkLogo}>
          <Plus className="w-7 h-7" />
        </div>
        <div className="mt-3 text-sm font-medium text-center">新規</div>
      </div>

      <LinkDialog state={dialog.add} set={(v) => setDialog({ ...dialog, add: v })} update={(form) => setQuickLinks([...quickLinks, form])} />
      <EditLinkDialog
        state={dialog.edit}
        set={(v) => setDialog({ ...dialog, edit: v })}
        initialData={dialog.index != null ? quickLinks[dialog.index] : null}
        update={(form) => {
          const updated = [...quickLinks];
          updated[dialog.index] = form;
          setQuickLinks(updated);
        }}
      />
    </div>
  );
};

QuickLinks.displayName = 'QuickLinks';
export default QuickLinks;
