import pkg from '../../package.json';

export const themeConfig = [
  {
    option: 'ミッドナイト',
    value: {
      theme: 'default',
      type: 'dark',
      settingsContainerColor: '#18283e',
      navItemActive: '#c1d4f1',
      settingsSearchBar: '#3c475a',
      settingsPanelItemBackgroundColor: '#405a77',
      settingsDropdownColor: '#162337',
      siteTextColor: '#a0b0c8',
      bgDesignColor: '66, 69, 73',
      glowWrapperColor: '255, 255, 255',
      switchColor: '#ffffff1a',
      switchEnabledColor: '#4c6c91',
      bgColor: '#111827',
      quickModalBgColor: '#252f3e',
      paginationTextColor: '#9baec8',
      paginationBorderColor: '#ffffff1c',
      paginationBgColor: '#141d2b',
      paginationSelectedColor: '#75b3e8',
      themeName: 'defaultTheme',
      /* loader */
      tabColor: "#111e2fb0",
      tabOutline: "#344646",
      barColor: "#09121e",
      tabBarColor: "#070e15",
      omninputColor: "#06080d8f",
      menuColor: "#1a252f"
    },
  },
  {
    option: 'モカ',
    value: {
      theme: 'mocha',
      type: 'dark',
      settingsContainerColor: '#312222',
      navItemActive: '#fdedea',
      settingsSearchBar: '#312929',
      settingsPanelItemBackgroundColor: '#3d2a2a',
      settingsDropdownColor: '#291c1c',
      siteTextColor: '#c7bab8',
      bgDesignColor: '65, 47, 47',
      glowWrapperColor: '255, 255, 255',
      switchColor: '#463131',
      switchEnabledColor: '#7c5f5f',
      bgColor: '#1a1514',
      quickModalBgColor: '#362c2c',
      paginationTextColor: '#c3b6b6',
      paginationBorderColor: '#ffffff1c',
      paginationBgColor: '#231b15',
      paginationSelectedColor: '#956f6f',
      themeName: 'mochaTheme',
      /* loader */
      tabColor: "#221a1a",
      tabOutline: "#3e3b3b",
      barColor: "#221a1a",
      tabBarColor: "#151313",
      omninputColor: "#1714148f",
      menuColor: "#282323"
    },
  },
  {
    option: 'フォレスト',
    value: {
      theme: 'forest',
      type: 'dark',
      settingsContainerColor: '#17281f',
      navItemActive: '#d4f3e1',
      settingsSearchBar: '#274233',
      settingsPanelItemBackgroundColor: '#315b45',
      settingsDropdownColor: '#15261c',
      siteTextColor: '#bfe5cf',
      bgDesignColor: '46, 66, 54',
      glowWrapperColor: '232, 255, 243',
      switchColor: '#375644',
      switchEnabledColor: '#3f7a5a',
      bgColor: '#0c1711',
      quickModalBgColor: '#15261c',
      paginationTextColor: '#cbe9cf',
      paginationBorderColor: '#ffffff1c',
      paginationBgColor: '#1d2d22',
      paginationSelectedColor: '#7ca387c4',
      themeName: 'forestTheme',
      /* loader */
      tabColor: "#162218",
      tabOutline: "#2d3e28",
      barColor: "#162218",
      tabBarColor: "#131513",
      omninputColor: "#1714148f",
      menuColor: "#1d221d"
    },
  },
  {
    option: 'ダーク',
    value: {
      theme: 'dark',
      type: 'dark',
      settingsContainerColor: '#18181c',
      navItemActive: '#f3f4f6',
      settingsSearchBar: '#1f1f23',
      settingsPanelItemBackgroundColor: '#2e2e34',
      settingsDropdownColor: '#151519',
      siteTextColor: '#fff',
      bgDesignColor: '73, 73, 73',
      glowWrapperColor: '255, 255, 255',
      switchColor: '#1f1f23',
      switchEnabledColor: '#3b3b44',
      bgColor: '#0b0b0e',
      quickModalBgColor: '#2d2d30',
      paginationTextColor: '#c9c9c9',
      paginationBorderColor: '#ffffff1c',
      paginationBgColor: '#1a1a1a',
      paginationSelectedColor: '#858585',
      themeName: 'darkTheme',
      /* loader */
      tabColor: "#1a1a1a",
      tabOutline: "#353535",
      barColor: "#191a19",
      tabBarColor: "#0d0d0d",
      omninputColor: "#0b0a0a8f",
      menuColor: "#1c1c1c"
    },
  },
  {
    option: 'ステラー',
    value: {
      theme: 'stellar',
      type: 'dark',
      settingsContainerColor: '#141620',
      navItemActive: '#9db4ff',
      settingsSearchBar: '#232538',
      settingsPanelItemBackgroundColor: '#2d2f44',
      settingsDropdownColor: '#181a26',
      siteTextColor: '#d6daff',
      bgDesignColor: '127, 127, 127',
      glowWrapperColor: '136, 169, 255',
      switchColor: '#25273a',
      switchEnabledColor: '#5560a4',
      bgColor: '#0a0b14',
      quickModalBgColor: '#24263a',
      paginationTextColor: '#c5c8e6',
      paginationBorderColor: '#ffffff1c',
      paginationBgColor: '#1a1b29',
      paginationSelectedColor: '#7f89d9',
      themeName: 'stellarTheme',
      /* loader */
      tabColor: "#16161c",
      tabOutline: "#343540",
      barColor: "#14141a",
      tabBarColor: "#0e0e13",
      omninputColor: "#0a0b0f8f",
      menuColor: "#18151c"
    },
  },

  {
    option: 'ホットピンク',
    value: {
      theme: 'pink',
      type: 'dark',
      settingsContainerColor: '#1a1618',
      navItemActive: '#ff69b4',
      settingsSearchBar: '#2a2528',
      settingsPanelItemBackgroundColor: '#221d20',
      settingsDropdownColor: '#1d181b',
      siteTextColor: '#ffbbd6',
      bgDesignColor: '255, 105, 180',
      glowWrapperColor: '255, 105, 180',
      switchColor: '#30282b',
      switchEnabledColor: '#ff69b4',
      bgColor: '#110d0f',
      quickModalBgColor: '#1c1619',
      paginationTextColor: '#ddb0c3',
      paginationBorderColor: '#ff69b440',
      paginationBgColor: '#1d1619',
      paginationSelectedColor: '#ff69b4',
      themeName: 'pinkTheme',
      /* loader */
      tabColor: "#281b22",
      tabOutline: "#2f2529",
      barColor: "#0f090c",
      tabBarColor: "#090507",
      omninputColor: "#10080d8f",
      menuColor: "#181115"
    },
  },

  {
    option: 'ライト',
    value: {
      theme: 'light',
      type: 'light',
      settingsContainerColor: '#e4e4e5',
      navItemActive: '#111827',
      settingsSearchBar: '#e5e7eb',
      settingsPanelItemBackgroundColor: '#e5e7eb',
      settingsDropdownColor: '#ffffff',
      siteTextColor: '#374151',
      bgDesignColor: '209, 213, 219',
      glowWrapperColor: '17, 24, 39',
      switchColor: '#cdcdcd',
      switchEnabledColor: '#9ca3af',
      bgColor: '#f9fafb',
      quickModalBgColor: '#f3f4f6',
      paginationTextColor: '#4c4c4c',
      paginationBorderColor: '#d1d1d170',
      paginationBgColor: '#ffffff',
      paginationSelectedColor: '#797979b8',
      themeName: 'lightTheme',
      /* loader */
      tabColor: "#ffffff",
      tabOutline: "#b2b2b2",
      barColor: "#ffffff",
      tabBarColor: "#d0d0d0",
      omninputColor: "#c6c6c68f",
      menuColor: "#fff"
    },
  },
  {
    option: 'ペーパー',
    value: {
      theme: 'paper',
      type: 'light',
      settingsContainerColor: '#e6dec7',
      navItemActive: '#1f2937',
      settingsSearchBar: '#ebe3cd',
      settingsPanelItemBackgroundColor: '#efe7cf',
      settingsDropdownColor: '#fffbeb',
      siteTextColor: '#474b52',
      bgDesignColor: '155, 150, 132',
      glowWrapperColor: '225, 225, 73',
      switchColor: '#c3baa6',
      switchEnabledColor: '#c7bfa8',
      bgColor: '#fefbf5',
      quickModalBgColor: '#fffbeb',
      paginationTextColor: '#4c4c4c',
      paginationBorderColor: '#d1d1d1',
      paginationBgColor: '#fffaea',
      paginationSelectedColor: '#494436b8',
      themeName: 'paperTheme',
      /* loader */
      tabColor: "#ffffff",
      tabOutline: "#b2b2b2",
      barColor: "#ffffff",
      tabBarColor: "#d0d0d0",
      omninputColor: "#c6c6c68f",
      menuColor: "#fff"
    },
  },
];

export const meta = [
  {
    option: 'デフォルト',
    value: {
      tabName: 'senninproxy',
      tabIcon: './icon.svg',
    },
  },
  {
    option: 'Google',
    value: {
      tabName: 'Google',
      tabIcon: 'https://google.com/favicon.ico',
    },
  },
  {
    option: 'Bing',
    value: {
      tabName: 'Bing',
      tabIcon: 'https://bing.com/favicon.ico',
    },
  },
  {
    option: 'Gmail',
    value: {
      tabName: 'Gmail',
      tabIcon: '/assets/img/gmail.ico',
    },
  },
  {
    option: 'Wikipedia',
    value: {
      tabName: 'Wikipedia',
      tabIcon: '/assets/img/wikipedia.ico',
    },
  },
  {
    option: 'Schoology',
    value: {
      tabName: 'Home | Schoology',
      tabIcon: '/assets/img/schoology.ico',
    },
  },
  {
    option: 'Google Classroom',
    value: {
      tabName: 'Home',
      tabIcon: '/assets/img/classroom.png',
    },
  },
  {
    option: 'ClassLink',
    value: {
      tabName: 'ClassLink',
      tabIcon: '/assets/img/classlink.ico',
    },
  },
  {
    option: 'Quizlet',
    value: {
      tabName: 'Quizlet: Study Tools & Learning Resources for Students and Teachers | Quizlet',
      tabIcon: '/assets/img/quizlet.png',
    },
  },
  {
    option: 'Big Ideas Math',
    value: {
      tabName: 'Big Ideas Math',
      tabIcon: '/assets/img/bigideasmath.ico',
    },
  },
  {
    option: 'Khan Academy',
    value: {
      tabName: 'Dashboard | Khan Academy',
      tabIcon: '/assets/img/khan.png',
    },
  },
];

export const searchConfig = [
  {
    option: 'Google',
    value: {
      engineName: 'Google',
      engine: 'https://www.google.com/search?q=',
      engineIcon:
        'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Google_Favicon_2025.svg/120px-Google_Favicon_2025.svg.png',
    },
  },
  {
    option: 'DuckDuckGo',
    value: {
      engineName: 'DuckDuckGo',
      engine: 'https://duckduckgo.com/?q=',
      engineIcon: 'https://duckduckgo.com/favicon.ico',
    },
  },
  {
    option: 'Bing',
    value: {
      engineName: 'Bing',
      engine: 'https://www.bing.com/search?q=',
      engineIcon: 'https://www.bing.com/favicon.ico',
    },
  },
  {
    option: 'Brave',
    value: {
      engineName: 'Brave',
      engine: 'https://search.brave.com/search?q=',
      engineIcon: 'https://brave.com/static-assets/images/brave-logo-sans-text.svg',
    },
  },
  {
    option: 'Yahoo',
    value: {
      engineName: 'Yahoo',
      engine: 'https://search.yahoo.com/search?p=',
      engineIcon: '',
    },
  },
  {
    option: 'Startpage',
    value: {
      engineName: 'Startpage',
      engine: 'https://www.startpage.com/sp/search?q=',
      engineIcon: '',
    },
  },
  {
    option: 'Ecosia',
    value: {
      engineName: 'Ecosia',
      engine: 'https://www.ecosia.org/search?q=',
      engineIcon: '',
    },
  },
  {
    option: 'Ask',
    value: {
      engineName: 'Ask',
      engine: 'https://www.ask.com/web?q=',
      engineIcon: '',
    },
  },
  {
    option: 'Baidu',
    value: {
      engineName: 'Baidu',
      engine: 'https://www.baidu.com/s?wd=',
      engineIcon: '',
    },
  },
  {
    option: 'Dogpile',
    value: {
      engineName: 'Dogpile',
      engine: 'https://www.dogpile.com/serp?q=',
      engineIcon: '',
    },
  },
  {
    option: 'Kagi',
    value: {
      engineName: 'Kagi',
      engine: 'https://kagi.com/search?q=',
      engineIcon: '',
    },
  },
  {
    option: 'Lycos',
    value: {
      engineName: 'Lycos',
      engine: 'https://search.lycos.com/web/?q=',
      engineIcon: '',
    },
  },
  {
    option: 'Mojeek',
    value: {
      engineName: 'Mojeek',
      engine: 'https://www.mojeek.com/search?q=',
      engineIcon: '',
    },
  },
  {
    option: 'Qwant',
    value: {
      engineName: 'Qwant',
      engine: 'https://www.qwant.com/?q=',
      engineIcon: '',
    },
  },
  {
    option: 'Swisscows',
    value: {
      engineName: 'Swisscows',
      engine: 'https://swisscows.com/web?query=',
      engineIcon: '',
    },
  },
  {
    option: 'Yandex',
    value: {
      engineName: 'Yandex',
      engine: 'https://yandex.com/search/?text=',
      engineIcon: '',
    },
  },
  {
    option: 'You.com',
    value: {
      engineName: 'You.com',
      engine: 'https://you.com/search?q=',
      engineIcon: '',
    },
  },
  {
    option: 'SearXNG (metasearch)',
    value: {
      engineName: 'SearXNG',
      engine: 'https://searx.be/search?q=',
      engineIcon: '',
    },
  },
  {
    option: 'Presearch',
    value: {
      engineName: 'Presearch',
      engine: 'https://presearch.com/search?q=',
      engineIcon: '',
    },
  },
  {
    option: 'Petal',
    value: {
      engineName: 'Petal',
      engine: 'https://petalsearch.com/search?query=',
      engineIcon: '',
    },
  },
  {
    option: 'Sogou',
    value: {
      engineName: 'Sogou',
      engine: 'https://www.sogou.com/web?query=',
      engineIcon: '',
    },
  },
  {
    option: 'Gigablast',
    value: {
      engineName: 'Gigablast',
      engine: 'https://www.gigablast.com/search?q=',
      engineIcon: '',
    },
  },
  {
    option: 'YaCy (p2p)',
    value: {
      engineName: 'YaCy',
      engine: 'https://yacy.searchlab.eu/yacysearch.json?query=',
      engineIcon: '',
    },
  },
  {
    option: 'WebCrawler',
    value: {
      engineName: 'WebCrawler',
      engine: 'https://www.webcrawler.com/serp?q=',
      engineIcon: '',
    },
  },
];

export const appsPerPageConfig = [
  { option: '20件', value: { itemsPerPage: 20 } },
  { option: '30件', value: { itemsPerPage: 30 } },
  { option: '40件', value: { itemsPerPage: 40 } },
  { option: '50件', value: { itemsPerPage: 50 } },
  { option: '75件', value: { itemsPerPage: 75 } },
  { option: '100件', value: { itemsPerPage: 100 } },
  { option: 'すべて', value: { itemsPerPage: 10000 } },
];

export const navScaleConfig = [
  { option: '50%', value: { navScale: 0.5 } },
  { option: '80%', value: { navScale: 0.8 } },
  { option: '90%', value: { navScale: 0.9 } },
  { option: '100%', value: { navScale: 1 } },
  { option: '110%', value: { navScale: 1.1 } },
  { option: '120%', value: { navScale: 1.2 } },
  { option: '130%', value: { navScale: 1.3 } },
];

export const prConfig = [
  {
    option: '自動',
    value: {
      prType: 'auto',
    },
  },
  {
    option: 'Ultravioletのみ',
    value: {
      prType: 'uv',
    },
  },
  {
    option: 'Scramjetのみ',
    value: {
      prType: 'scr',
    },
  },
];

export const designConfig = [
  {
    option: 'ドット',
    value: {
      bgDesign: 'dots',
      getCSS: (color) => `radial-gradient(circle, rgba(${color},0.112) 3px, transparent 1px)`,
    },
  },
  {
    option: 'ストライプ',
    value: {
      bgDesign: 'diagonalStripes',
      getCSS: (color) => `
        repeating-linear-gradient(
          45deg,
          rgba(${color},0.15),
          rgba(${color},0.15) 2px,
          transparent 2px,
          transparent 8px
        )`,
    },
  },
  {
    option: 'グリッド',
    value: {
      bgDesign: 'grid',
      getCSS: (color) => `
        linear-gradient(to right, rgba(${color},0.2) 1px, transparent 1px),
        linear-gradient(to bottom, rgba(${color},0.2) 1px, transparent 1px)
      `,
    },
  },
  {
    option: 'なし',
    value: {
      bgDesign: 'none',
    },
  },
];
