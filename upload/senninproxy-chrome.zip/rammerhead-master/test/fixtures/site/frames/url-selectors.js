window.urlSelectorsScriptRan = true;
